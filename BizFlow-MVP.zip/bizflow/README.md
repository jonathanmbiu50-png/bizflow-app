# BizFlow — SaaS starter application

A working Flask + SQLAlchemy business-management MVP with tenant-scoped accounts, session authentication, dashboard, POS, stock management, customers, transaction history and subscription-plan selection.

## Run locally

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:5000. A new account receives a 14-day trial. To load sample records, run `flask --app app seed-demo` then sign in with:

- Email: `demo@bizflow.local`
- Password: `Demo12345!`

## Included

- Registration/login with Werkzeug password hashing and HTTP-only session cookie
- A separate business/workspace per registration; business-owned records are queried by the signed-in user's `business_id`
- Dashboard totals and seven-day sales chart
- POS sale creation, stock decrement, and printable receipt
- Product creation, price and stock updates, low-stock alerts
- Customer creation and purchase counts
- Sales history
- Basic, Business and Enterprise plan selection (KSh 999 / 2,499 / 5,999)
- 14-day trial metadata and platform-admin overview endpoint

## Before production

This is a functional MVP foundation, not a production launch. Use PostgreSQL, set a strong `SECRET_KEY`, enable HTTPS and secure cookies, add CSRF protection and rate limiting, implement email verification/password reset, audit logs, backups, migrations, tests, monitoring and a proper employee/branch permission model. The admin overview is restricted to users with the `platform_admin` role; create that role only through a protected operator process. Add server-side verified M-Pesa/card webhooks before marking subscriptions paid. Plan selection currently records a requested plan only and never charges a customer. Add idempotency keys and stronger transaction locking for high-volume POS use.

## Deploy

A typical WSGI command is `gunicorn app:app`. Configure `DATABASE_URL` to a managed PostgreSQL database and set `COOKIE_SECURE=1` behind HTTPS.
